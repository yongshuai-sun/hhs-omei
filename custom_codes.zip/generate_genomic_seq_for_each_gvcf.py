#$  python3.5    generate_genomic_seq_for_each_gvcf.py s-2018-LZQ-002-...g.vcf /home/shuai/work/castanea_genome_ref_nanopore/BL.fa
#this script can be used to generate fasta-sequence for an individual. GVCF and the filtered vcf files are needed. The reference genomic sequence should be listed. 

minDepth=8
maxDepth=60

import sys

def read_reference_fa(ref_fasta): # FORMAT : fasta # better no space in CHROM_name
    ref_dict={}  # for each key=scaffold_name, its value is the DNA sequence #{'scaffold00002':'AAGGGCGGCGCTA',....}
    CHROM=''
    chrom_seq=[]
    total_length=0
    for line in open(ref_fasta,'r'):
        temp=line.strip()
        if len(temp)==0 : continue
        if temp.startswith('>') : #
            if chrom_seq != []:
                seq0=''.join(chrom_seq)
                ref_dict[CHROM]=seq0
            CHROM=temp[1:]
            chrom_seq=[]
        else :
            temp=temp.replace(' ', '')
            chrom_seq.append(temp)
    seq0=''.join(chrom_seq)
    ref_dict[CHROM]=seq0 # the last CHROM and seq 
    for seq in ref_dict.values():
        total_length=total_length+len(seq)
    print('GET ref_dict: '+ref_fasta+ ' , number of scaffolds: '+str(len(ref_dict.keys()))+' , total length: '+str(total_length)+' . Over.')
    return ref_dict

#ref_fasta="/home/shuai/work/chestnut_analyze/chestnut_ref/Cm_v1.1_scaffolds.fa"
#ref_dict0=read_reference_fa("/home/shuai/work/chestnut_analyze/chestnut_ref/Cm_v1.1_scaffolds.fa")

def list_dict(ref_dict):
    i_dict={}  # {'scaffold00002':['A', 'A', 'G', 'G', 'G', 'C', 'G', 'G', 'C', 'G', 'C', 'T', 'A',...]}
    for k,v in ref_dict.items():
        i_dict[k]=list(v)
    print("From string_dict to list_dict. ")
    return i_dict

def string_dict(confident_dict):
    new_dict={}
    for k,v in confident_dict.items():
        seq=''.join(v)
        new_dict[k]=seq
    print("From list_dict to string_dict. ")
    return new_dict

def empty_ids_dict(ref_dict):
    ids_dict={}  # {'scaffold00002':['?', '?', '?', '?', '?', '?', '?', '?',...]}
    for k,v in ref_dict.items():
        ids_dict[k]=list('?'*len(v))
    return ids_dict

def get_depth(t8,t9): #get depth from format and sample # GT:DP:GQ:MIN_DP:PL      0/0:1:3:1:0,3,27
    if 'DP' in t8:
        if t8[1]=='DP': depth=int(t9[1])
        elif t8[2]=='DP': depth=int(t9[2])
        else:
            t_dict={}
            for i in range(len(t8)):
                t_dict[t8[i]] = t9[i]
            depth=int(t_dict['DP'])    #get depth, over.
    return depth

def get_GT(t8,t9): #get GT from format and sample #gatk4.1.2.0 output "0|0" format
    # ['GT','DP','GQ','MIN_DP','PL']      ['0/0','1','3','1','0,3,27']
    # GT:AD:DP:GQ:PGT:PID:PL:PS       1|1:0,23:23:69:1|1:11938_C_T:1027,69,0:11938  
    if 'GT' in t8:
        if t8[0]=='GT': gt=t9[0]
        else:
            t_dict={}
            for i in range(len(t8)):
                t_dict[t8[i]] = t9[i]
            gt=t_dict['GT']    #get GT, over.
    return int(gt[0]),int(gt[2])

def base_call(x,y,pos=0):
    x=x.upper()
    y=y.upper()
    if x=='U': x='T'
    if y=='U': y='T'
    if y==x:  return y  #print("1/1", end=' | ')
    if sorted([x,y])==sorted(['A','T']): return 'W' # 0/1 1/2
    if sorted([x,y])==sorted(['A','C']): return 'M'
    if sorted([x,y])==sorted(['A','G']): return 'R'
    if sorted([x,y])==sorted(['C','T']): return 'Y'
    if sorted([x,y])==sorted(['G','T']): return 'K'
    if sorted([x,y])==sorted(['C','G']): return 'S'
    print('unknow nucleotide state: '+x+'  ,  '+y+' @ ',pos+'. Replace by N.')
    return 'N'

def gcvf_to_ids_dict(gvcf_file, ref_dict, min_depth=5,max_depth=1000000):
    ids_dict=empty_ids_dict(ref_dict)
    n,m=0,10000000
    for line1 in open(gvcf_file,'r'):
        line=line1.strip()
        if line.startswith('#') or len(line)==0: continue  # for a non-variant line , record its pos if depth is confident.
        temp=line.split()
        if len(temp)!=10:
            print('NOT 10 columns: '+line)
            sys.exit()
        n=n+1
        if n%m == 0:
            print(int(n/m),end='0M,')
            print(ids_dict[temp[0]][:20]) #
        if '0/0' in temp[9].split(':') and 'END' in temp[7] :
            begin_pos=int(temp[1])
            end_pos=int( temp[7].split('=')[1] )
            depth=get_depth(temp[8].split(':'),temp[9].split(':'))
            if depth >= min_depth and depth <= max_depth:
                ids_dict[temp[0]][begin_pos-1:end_pos]=ref_dict[temp[0]][begin_pos-1:end_pos]
        elif '0/0' in temp[9].split(':') and 'END' not in temp[7] and len(temp[3]) == 1 :
            depth=get_depth(temp[8].split(':'),temp[9].split(':'))
            if depth >= min_depth and depth <= max_depth:
                ids_dict[temp[0]][int(temp[1])-1]=ref_dict[temp[0]][int(temp[1])-1]  ##
    print('GVCF over.')
    return ids_dict #
# its value is in type of list

def snp_into_ids_dict(snp_vcf_file, ids_dict):
    confident_dict=ids_dict
    n,m=0,10000000
    for line in open(snp_vcf_file,'r'):
        if line.startswith('#') or 'GT' not in line or 'Filter' in line : continue
        temp=line.split()
        if len(temp)!=10:
            print('NOT 10 columns: '+line)
            sys.exit()
        n=n+1
        if n%m == 0:
            print(int(n/m),end='0M,')
            print(confident_dict[temp[0]][:20])
        ref_alt=temp[3]+temp[4]
        if ',' in ref_alt : ref_alt=ref_alt.replace(',','')
        t1,t2=get_GT(temp[8].split(':'),temp[9].split(':'))
        snp_base=base_call(ref_alt[t1],ref_alt[t2],temp[1])
        confident_dict[temp[0]][int(temp[1])-1] = snp_base
        #if snp_base not in "ATCG": print(snp_base,end='')
    print('snp_vcf over.')
    return confident_dict,n
# includes confident SNPs and non-variant sites. n is the number of confident SNPs
# its value is in type of list

#*_*_*_*_*_main function_*_*_*_*_*#
def produce_ids_sequence(ref_fasta,snp_vcf_file,gvcf_file,min_depth=5,max_depth=1000000): #s-2018-LZQ-003-11.g.vcf
    ref_dict0=read_reference_fa(ref_fasta) #if 2>0:
    ref_dict=list_dict(ref_dict0) #From string_dict to list_dict.
    ids_dict=gcvf_to_ids_dict(gvcf_file, ref_dict, minDepth,maxDepth)
    confident_dict,n=snp_into_ids_dict(snp_vcf_file, ids_dict)
    confident_dict=string_dict(confident_dict)
    #if 2>0:
    total_seq0=[]
    for v in confident_dict.values():
        total_seq0.append(v.upper())
    total_seq=''.join(total_seq0)
    missing_sites=total_seq.count('?')+total_seq.count('N')
    confident_sites = len(total_seq) - missing_sites
    a,t,c,g=total_seq.count('A'),total_seq.count('T'),total_seq.count('C'),total_seq.count('G')
    heterozygous_sites = confident_sites-a-t-c-g #
    print('GET fasta of : '+vcf_file+' , depth['+str(minDepth)+','+str(maxDepth)+']'+' , length: '+str(len(total_seq)), end='')
    print(' , confident_sites: '+str(confident_sites)+' , SNPs_toREF: '+str(n)+' , heterozygous_sites: '+str(heterozygous_sites)+' , missing: '+str(missing_sites))
    #if 2>0:
    ids_seq_file=gvcf_file.split('.')[0]+'.fasta' 
    ouput_seq=open(ids_seq_file,'w')
    all_keys=sorted(list(confident_dict.keys()))
    for k in all_keys:
        ouput_seq.write('>'+k+'\n')
        ouput_seq.write(confident_dict[k]+'\n')
    ouput_seq.close()
    return 0

#
#*_*_*_*_*_*_*_*_*_*_*#
#python3.5    generate_ids_seq5.py yexianggu-3.g.vcf /home/shuai/work/chestnut_analyze/chestnut_ref/Cm_v1.1_scaffolds.fa
#*_*_*_*_*_*_*_*_*_*_*#
 
ref_fasta=sys.argv[2]
vcf_file=sys.argv[1]
snp_vcf_file=vcf_file.split('.')[0]+'.snp.filter.vcf'
gvcf_file=vcf_file.split('.')[0]+'.g.vcf'
produce_ids_sequence(ref_fasta,snp_vcf_file,gvcf_file,minDepth,maxDepth)
#
#*_*_*_*_*_*_*_*_*_*_*#

"""
ref_fasta="/home/shuai/work/chestnut_analyze/chestnut_ref/Cm_v1.1_scaffolds.fa"
ref_dict0=read_reference_fa("/home/shuai/work/chestnut_analyze/chestnut_ref/Cm_v1.1_scaffolds.fa")

vcf_file="test.g.vcf"
snp_vcf_file=vcf_file.split('.')[0]+'.snp.filter.vcf'
gvcf_file=vcf_file.split('.')[0]+'.g.vcf'
produce_ids_sequence(ref_fasta,snp_vcf_file,gvcf_file,minDepth,maxDepth)
#
#*_*_*_*_*_*_*_*_*_*_*#

if 2 > 0 :
    for vcf in open('vcfs','r'):
        if 'vcf' not in vcf: continue
        snp_vcf_file=vcf.strip()
        gvcf_file=snp_vcf_file.split('.')[0]+'.g.vcf0'
        print('Generate fasta seqence of : '+snp_vcf_file)
        produce_ids_sequence(ref_fasta,snp_vcf_file,gvcf_file,minDepth,maxDepth)
"""
print('Over.')

