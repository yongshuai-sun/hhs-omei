# command: python3   compute_pai_dxy_maxFST_GC4window_phy.py phy_listfile
# This py is used to compute pai, dxy (Nei & Li, 1979, PNAS 76:5269-5273), pairwise FST (Hudson, Slatkin and Maddison, 1992, Genetics 132:583-589) and maxFST.
# The DNA sequence data should be in sequential Phylip format with individual names and sequence data all on one line and separated by a tab. All the sequence-file-names were listed in the phy_listfile.
# The map file is organized similarly to the sequence data file with one individual per row and a tab separating the individual��s name from the name of the taxon/population it belongs to. The individuals should be in the same order as the DNA sequence data file with all individuals in a particular taxon grouped together sequentially.
# The minSS is the min sample size per population. 

import sys

# -.-.-  data_setting   -.-.-.-.-.-.-
phy_file = sys.argv[1] #'phy.txt' # store the name of phy-files 
map_file='map.txt' #
minSS = '20' #  
# -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- 

def pai_snp(n,p):
    return 2.0*n*p*(1.0-p)/(n-1.0)

def dxy_snp(p1,p2):
    return p1*(1.0-p2)+p2*(1.0-p1)

def FST_snp(n1,p1,n2,p2):
    a=(p1-p2)*(p1-p2) - p1*(1.0-p1)/(n1-1.0) - p2*(1.0-p2)/(n2-1.0)
    b=p1*(1.0-p2)+p2*(1.0-p1)
    if b == 0 or a>b:   return 0,0,0
    if a <= 0.000001:  return 0,0,b
    return a/b,a,b

def read_map(map_file):
    pops_dict={}
    for line in open(map_file,'r'):
        l=line.split()
        if l[1] not in pops_dict:
            pops_dict[l[1]]=[]
        pops_dict[l[1]].append(l[0])
    return pops_dict
pops=read_map(map_file.strip())
#pops=read_map(map_file.strip())

def nucleotide(X): #ACGT?
    X=X.upper()
    if X in "ATCG": return X+'/'+X
    if X=='U': return 'T/T'
    if X=='W': return 'A/T'
    if X=='M': return 'A/C'
    if X=='R': return 'A/G'
    if X=='Y': return 'T/C'
    if X=='K': return 'T/G'
    if X=='S': return 'C/G'
    if X in ".?N": return '?/?'
    else:
        print('unknow nucleotide state: [ '+X+' ] ! Replace it by ?/?')
    return '?/?'

def pop_data(phy_dict):# parse Ambiguity
    pop_d={}
    for k,v in pops.items():
        pop_d[k]=[]
        for ind in v:
            seq1=[nucleotide(X)[0] for X in phy_dict[ind]]
            pop_d[k].append(''.join(seq1))
            seq2=[nucleotide(X)[-1] for X in phy_dict[ind]]
            pop_d[k].append(''.join(seq2))
        #print(k,len(pop_d[k]))
    return pop_d
#pop_d looks like {'pop1':['ACGTAGCTGTCG','ACGTAGCT?TCG','?CG?AGCTGTCG'] ... }  #no Ambiguity, ACGT?

def matrix_2_ACGT_count(pop_d): # many pops in pop_d
    acgt_count_d={}
    for pop in pop_d.keys():
        pop_acgt_count=[]
        for i in range(len(pop_d[pop][0])):
            s=[]
            site=[seq[i] for seq in pop_d[pop]]
            bases=''.join(site).replace('?','')
            for base in 'ACGT':
                s.append(bases.count(base))
            pop_acgt_count.append(s)
        acgt_count_d[pop]=pop_acgt_count
    return acgt_count_d
#acgt_count_d looks like {'pop1':[[1,0,0,23],[0,3,6,0],[0,0,0,0],...] ... } order:ACGT ==pop_data
#length of acgt_count_d[pop] == windowLength

def read_phy(phy):
    # read all sequences into the phy_dict
    phy_dict={}
    for line in open(phy):
        if len(line) < 21 : continue
        l = line.split()
        phy_dict[l[0]]=l[1] #key=seq_name and value=ACGT_seq
    phy_d=pop_data(phy_dict) #group these diploid sequences into each population after trans-into haplotypic sequences
    acgt_count_d=matrix_2_ACGT_count(phy_d) #for each population, count the number of ACGT at each site
    return acgt_count_d
#after reading the phy-file, we count ACGT at each site per pop; return a dict with len(pops) values.

def GC_content(acgt_count_d):
    gc_dict={}
    for popi,acgt_count in acgt_count_d.items():
        tot=0
        gc=0
        for base in acgt_count:
            tot=tot+sum(base)
            gc=gc+sum(base[1:3])
        if tot == 0:
            gc_dict[popi]=-1
        else:
            gc_dict[popi]=gc*1.0/tot
    return gc_dict

def list_alleles(acgt_count): #acgt_count=[0,3,6,0]
    a_dict={}
    for i in range(len(acgt_count)):
        a_dict['ACGT'[i]]=acgt_count[i]
    a1 = sorted(a_dict.items(), key=lambda x: x[1], reverse=True) #a1 looks like (('A',22),('C',6),(G,0),(T,0))
    a_s=[x[0] for x in a1 if x[1] >0]
    return a_s


def compute_pai_pop(pop_data): #compute pai in unit of per site, not per SNP, not per window
    #ess=0 #per site, sample size in haploid
    pai_all_site=[]
    Length_window=0
    for site in pop_data:
        #one site by one site
        ess=sum(site)
        if ess < int(minSS): continue
        a_s=list_alleles(site)
        if len(a_s) > 1: 
            pai_all_site.append(pai_snp(ess, max(site)*1.0/ess))
        Length_window = Length_window + 1
    if Length_window==0: return 0
    pai_ = sum(pai_all_site)/Length_window
    if pai_ >1.0 : print("pai_ >1.0", Length_window, sum(pai_all_site))
    return pai_

def compute_pai_phy(acgt_count_d):
    pai_phy={}
    for pop,d in acgt_count_d.items(): #d is an pop_acgt_count
        pai_phy[pop]=compute_pai_pop(d)
    return pai_phy


def add_acgt_count(c1,c2):
    c=[c1[i]+c2[i] for i in range(len(c1))]
    return c


def two_pops_np(c1,c2): # acgt_count per site from 2 pops #for fst and dxy
    c=add_acgt_count(c1,c2)
    allele1=list_alleles(c)[0] # just consider the major allele, even if it has 3 or 4 states
    n1=sum(c1)*1.0
    n2=sum(c2)*1.0
    if n1 ==0 or n2 ==0: return 0,0,0,0
    p1=c1['ACGT'.index(allele1)]*1.0/n1
    p2=c2['ACGT'.index(allele1)]*1.0/n2
    return n1,p1,n2,p2

def compute_fst_dxy_phy(pop_matrix):#compute pairwise fst per window and dxy per site in this window
    fst_dict={}
    dxy_dict={}
    all_pops_list=sorted(list(pop_matrix.keys()))
    for i in range(len(all_pops_list)):
        a1=pop_matrix[all_pops_list[i]] # data of pop1
        for j in range(len(all_pops_list)):
            if i<=j: continue
            a2=pop_matrix[all_pops_list[j]] # data of pop2
            #
            Length_window=0
            snp_ess_window=0
            k12=all_pops_list[i]+'&'+all_pops_list[j] #name for each pairwise-pops
            fst_dict[k12]=[]
            dxy_dict[k12]=[]
            for b in range(len(a2)): # compute fst and dxy for each base
                if sum(a1[b])<int(minSS) or sum(a2[b])<int(minSS): continue
                n1,p1,n2,p2=two_pops_np(a1[b],a2[b])
                if p1 >0.99999 and p2 >0.99999: #non-variant site
                    Length_window=Length_window+1
                    continue
                fst=FST_snp(n1,p1,n2,p2)
                dxy=dxy_snp(p1,p2)
                fst_dict[k12].append(fst)
                dxy_dict[k12].append(dxy)
                Length_window=Length_window+1
                snp_ess_window=snp_ess_window+1
            if snp_ess_window == 0:
                dxy_dict[k12]=0
                fst_dict[k12]=0
            else:
                dxy_dict[k12]= sum(dxy_dict[k12])*1.0/Length_window
                fst_dict[k12]= max([f[0] for f in fst_dict[k12]]) # new FST, maxFST
                #fst_b=sum([f[2] for f in fst_dict[k12]])
                #if fst_b <= 0.0000001: fst_dict[k12]=0
                #else: fst_dict[k12]= sum([f[1] for f in fst_dict[k12]])*1.0/fst_b
    return fst_dict,dxy_dict

def pp_name(pp):# pp=h&m  return m&h
    p0=pp.split('&')
    return p0[1]+'&'+p0[0]

def output_res(phy_file):
    outfile=open(phy_file+'.pai_maxFST_dxy_GC'+minSS,'w')
    all_pops=sorted(list(pops.keys())) #sort all pops and used it in outputing
    pai_pop_names='\tpai_'.join(all_pops)
    gc_pop_names='\tGC_'.join(all_pops)
    pairwise_pop_names=[] #used in output
    for i in range(len(all_pops)):
        for j in range(len(all_pops)):
            if j<=i: continue
            temp_name=all_pops[i]+'&'+all_pops[j]
            pairwise_pop_names.append(temp_name)
    print(pairwise_pop_names)
    fst_names='\tmFST_'.join(pairwise_pop_names)
    dxy_names='\tDxy_'.join(pairwise_pop_names)
    outfile.write('contig\tstart\tend\tpai_'+pai_pop_names+'\tmFST_'+fst_names+'\tDxy_'+dxy_names+'\tGC_'+gc_pop_names+'\n')
    for phy in open(phy_file,'r').readlines():
        pop_matrix=read_phy(phy.strip()) #core function*******
        pai_phy=compute_pai_phy(pop_matrix) # is a dict, pai_phy['pop1']=0.0066 #core function*******
        gc_phy=GC_content(pop_matrix) # is a dict, gc_phy['pop1']=0.36 #core function*******
        Fst_phy,dxy_phy=compute_fst_dxy_phy(pop_matrix) #dxy_phy['pop1&pop2']=0.012 #core function*******
        window_name='\t'.join(phy.strip().split('/')[-1].split('.')[0].split('_'))
        pai_s=['%.6f' %float(pai_phy[pp]) for pp in all_pops] # '\t'.join(pai_s) #4she5ru
        gc_s=['%.6f' %float(gc_phy[pp]) for pp in all_pops] # '\t'.join(gc_s) #4she5ru
        fst_s=[]
        dxy_s=[]
        for pp in pairwise_pop_names:
            if pp in Fst_phy.keys():
                fst_s.append('%.6f' %float(Fst_phy[pp]))
            elif pp_name(pp) in Fst_phy.keys():
                fst_s.append('%.6f' %float(Fst_phy[pp_name(pp)]))
            else:
                fst_s.append('!')
                print("fst_s.append('!')",pp,Fst_phy)
            if pp in dxy_phy.keys():
                dxy_s.append('%.6f' %float(dxy_phy[pp]))
            elif pp_name(pp) in dxy_phy.keys():
                dxy_s.append('%.6f' %float(dxy_phy[pp_name(pp)]))
            else:
                dxy_s.append('!')
                print("dxy_s.append('!')",pp,dxy_phy)
        #dxy_s=[str(dxy_phy[pp]) for pp in pairwise_pop_names]
        outfile.write(window_name+'\t'+'\t'.join(pai_s)+'\t'+'\t'.join(fst_s)+'\t'+'\t'.join(dxy_s)+'\t'+'\t'.join(gc_s)+'\n')
        print(window_name+'\t'+'\t'.join(pai_s)+'\t'+'\t'.join(fst_s)+'\t'+'\t'.join(dxy_s)+'\t'+'\t'.join(gc_s))
    outfile.close()
    return 0



print(sorted(list(pops.keys())))
output_res(phy_file)
# over.
