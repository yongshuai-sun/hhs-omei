3 data files used in performing coalescent test of HHS using fastsimcoal2
