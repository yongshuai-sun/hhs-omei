8 files used in producing psmc and smc++ figures
